<?php
//require_once 'C:\xampp\htdocs\composerthemedemo2\src\gallary_mange.php';

//echo WP_ENV; die();
$wp_gallary = new wp_demo_gallary_manage\wp_gallary;


$books = new custom_post_type\cpt('books');
//require_once('register_style_script.php');

$books->capability_type =  array('psp_project',$books->post_type_name);
$books->map_meta_cap =  true;

$books->register_taxonomy('gallery_category');
$books->taxonomy_capabilities = array(
			'manage_terms'=> 'manage_categories',
			  'edit_terms'=> 'manage_categories',
			  'delete_terms'=> 'manage_categories',
			  'assign_terms' => 'read'
			);
// define the columns to appear on the admin edit screen
$books->columns(array(
	'cb' => '<input type="checkbox" />',
    'title' => __('Title'),
    'gallery_category' => __('Gallery Category'),
    'date' => __('Date')
));
// use "pages" icon for post type
$books->menu_icon("dashicons-book-alt");

require_once get_template_directory() . '/inc/template-functions.php';

require_once get_template_directory() . '/inc/register_style_script.php';


function psp_add_project_management_role() {
 add_role('psp_project_manager',
            'Gallery Manager',
            array(
                'read' => true,
                'edit_posts' => false,
                'delete_posts' => false,
                'publish_posts' => false,
                'upload_files' => true,
            )
        );
   }
add_action('admin_init','psp_add_project_management_role',998);
add_action('admin_init','psp_add_role_caps',999);
function psp_add_role_caps() {
		// Add the roles you'd like to administer the custom post types
		$roles = array('psp_project_manager');
		// Loop through each role and assign capabilities
		foreach($roles as $the_role) { 
			 global $role;
				$role = get_role($the_role);
	             $role->add_cap( 'read' );
	             $role->add_cap( 'read_books');
	             $role->add_cap( 'read_private_books' );
	             $role->add_cap( 'edit_books' );
	             $role->add_cap( 'edit_books' );
	             $role->add_cap( 'edit_books' );
	             $role->add_cap( 'edit_published_books' );
	             $role->add_cap( 'publish_books' );
	             $role->add_cap( 'delete_others_books' );
	             $role->add_cap( 'delete_private_books' );
	             $role->add_cap( 'delete_published_books' );
		}
}

function posts_for_current_author($query) {
    global $pagenow;
    if( 'edit.php' != $pagenow || !$query->is_admin )
    return $query;

  global $user_ID;
  $user = get_user_by('ID',$user_ID);
  
  if( isset($_REQUEST['post_type']) && $_REQUEST['post_type'] == 'book' &&  in_array("psp_project_manager",$user->roles) ) {

        $query->set('author', $user_ID );
    }
    return $query;
}
add_filter('pre_get_posts', 'posts_for_current_author');
?>

